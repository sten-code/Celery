ace.define("ace/theme/celery", ["require","exports","module"], function(require, exports, module) {
    exports.isDark = true;
    exports.cssClass = "ace-celery";
    exports.cssText = `
.ace-celery .ace_gutter {
  background: #181825;
  color: #BAC2DE;
}

.ace-celery .ace_print-margin {
  width: 1px;
  background: #CDD6F4;
}

.ace-celery {
  background-color: #181825;
  color: #CDD6F4;
}

.ace-celery .ace_cursor {
  color: #CDD6F4;
}


.ace-celery .ace_scrollbar::-webkit-scrollbar {
  height: 7px;
  width: 7px;
}

.ace-celery .ace_scrollbar::-webkit-scrollbar-track
{
  background-color: #181825;
  border-radius: 10px;
}

.ace-celery .ace_scrollbar::-webkit-scrollbar-thumb {
  background-color: #585B70;
  border-radius: 10px;
  margin: 5px;
}


.ace-celery .ace_marker-layer .ace_selection {
  background: #45475A;
}

.ace-celery.ace_multiselect .ace_selection.ace_start {
  box-shadow: 0 0 3px 0px #45475A;
  border-radius: 2px;
}

.ace-celery .ace_marker-layer .ace_step {
  background: #CDD6F4;
}

.ace-celery .ace_marker-layer .ace_bracket {
  margin: -1px 0 0 -1px;
  
  border: 1px solid #585B70;
}

.ace-celery .ace_marker-layer .ace_active-line {
  background: #313244;
}

.ace-celery .ace_gutter-active-line {
  background-color: #313244;
}

.ace-celery .ace_marker-layer .ace_selected-word {
  border: 1px solid #45475A;
}

.ace-celery .ace_fold {
  background-color: #1E1E2E;
  border-color: #1E1E2E;
}

.ace-celery .ace_keyword {
  color: #F92672;
}

.ace-celery .ace_constant.ace_language {
  color: #AE81FF;
}

.ace-celery .ace_constant.ace_numeric {
  color: #AE81FF;
}

.ace-celery .ace_constant.ace_character {
  color: #AE81FF;
}

.ace-celery .ace_constant.ace_other {
  color: #AE81FF;
}

.ace-celery .ace_support.ace_function {
  color: #66D9EF;
}

.ace-celery .ace_support.ace_constant {
  color: #66D9EF;
}

.ace-celery .ace_support.ace_class {
  font-style: italic;
  color: #66D9EF;
}

.ace-celery .ace_support.ace_type {
  font-style: italic;
  color: #66D9EF;
}

.ace-celery .ace_storage {
  color: #F92672;
}

.ace-celery .ace_storage.ace_type {
  font-style: italic;
  color: #66D9EF;
}

.ace-celery .ace_invalid {
  color: #F8F8F0;
  background-color: #F92672;
}

.ace-celery .ace_invalid.ace_deprecated {
  color: #F8F8F0;
  background-color: #AE81FF;
}

.ace-celery .ace_string {
  color: #E6DB74;
}

.ace-celery .ace_comment {
  color: #75715E;
}

.ace-celery .ace_variable {
  color: #A6E22E;
}

.ace-celery .ace_variable.ace_parameter {
  font-style: italic;
  color: #FD971F;
}

.ace-celery .ace_entity.ace_other.ace_attribute-name {
  color: #A6E22E;
}

.ace-celery .ace_entity.ace_name.ace_function {
  color: #A6E22E;
}

.ace-celery .ace_entity.ace_name.ace_tag {
  color: #F92672;
}

.ace-celery .ace_indent-guide {
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAAEklEQVQImWNgYGBgYHB3d/8PAAOIAdULw8qMAAAAAElFTkSuQmCC) right repeat-y
}

.ace-celery .ace_indent-guide-active {
  background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACAQMAAACjTyRkAAAABlBMVEUAAADCwsK76u2xAAAAAXRSTlMAQObYZgAAAAxJREFUCNdjYGBoAAAAhACBGFbxzQAAAABJRU5ErkJggg==") right repeat-y;
}

.ace-celery .ace_search {
  background: #1E1E2E;
  border: 1px solid #45475A;
}

.ace-celery .ace_button {
  color: #CDD6F4;
}

.ace-celery .ace_button:hover {
  background-color: #313244;
}

.ace-celery .ace_search_field {
  background-color: #1E1E2E;
  color: #CDD6F4;
  border: 1px solid #45475A;
}

.ace-celery .ace_searchbtn {
  background-color: #1E1E2E;
  border: 1px solid #45475A;
}

`;

    var dom = require("../lib/dom");
    dom.importCssString(exports.cssText, exports.cssClass);
});