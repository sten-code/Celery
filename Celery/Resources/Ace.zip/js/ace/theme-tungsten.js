ace.define("ace/theme/tungsten", ["require","exports","module"], function(require, exports, module) {
    exports.isDark = true;
    exports.cssClass = "ace-tungsten";
    exports.cssText = `
.ace-tungsten .ace_gutter {
  background: #191B21;
  color: rgb(135,137,144);
}

.ace-tungsten .ace_print-margin {
  width: 1px;
  background: #e8e8e8;
}

.ace-tungsten {
  background-color: #191B21;
  color: #c5c7d3;
}

.ace-tungsten .ace_cursor {
  color: #c5c7d3;
}


.ace-tungsten .ace_scrollbar::-webkit-scrollbar {
  height: 7px;
  width: 7px;
}

.ace-tungsten .ace_scrollbar::-webkit-scrollbar-track
{
  background-color: #191b21;
  border-radius: 10px;
}

.ace-tungsten .ace_scrollbar::-webkit-scrollbar-thumb {
  background-color: #373b49;
  border-radius: 10px;
  margin: 5px;
}


.ace-tungsten .ace_marker-layer .ace_selection {
  background: #2C2F3A;
}

.ace-tungsten.ace_multiselect .ace_selection.ace_start {
  box-shadow: 0 0 3px 0px #191B21;
  border-radius: 2px;
}

.ace-tungsten .ace_marker-layer .ace_step {
  background: rgb(198, 219, 174);
}

.ace-tungsten .ace_marker-layer .ace_bracket {
  margin: -1px 0 0 -1px;
  
  border: 1px solid #373b49;
}

.ace-tungsten .ace_marker-layer .ace_active-line {
  background: #21232b;
}

.ace-tungsten .ace_gutter-active-line {
  background-color: #21232b;
}

.ace-tungsten .ace_marker-layer .ace_selected-word {
  border: 1px solid #2C2F3A;
}

.ace-tungsten .ace_fold {
  background-color: #1d1f26;
  border-color: #1d1f26;
}

.ace-tungsten .ace_keyword {
  color: #F92672;
}

.ace-tungsten .ace_constant.ace_language {
  color: #AE81FF;
}

.ace-tungsten .ace_constant.ace_numeric {
  color: #AE81FF;
}

.ace-tungsten .ace_constant.ace_character {
  color: #AE81FF;
}

.ace-tungsten .ace_constant.ace_other {
  color: #AE81FF;
}

.ace-tungsten .ace_support.ace_function {
  color: #66D9EF;
}

.ace-tungsten .ace_support.ace_constant {
  color: #66D9EF;
}

.ace-tungsten .ace_support.ace_class {
  font-style: italic;
  color: #66D9EF;
}

.ace-tungsten .ace_support.ace_type {
  font-style: italic;
  color: #66D9EF;
}

.ace-tungsten .ace_storage {
  color: #F92672;
}

.ace-tungsten .ace_storage.ace_type {
  font-style: italic;
  color: #66D9EF;
}

.ace-tungsten .ace_invalid {
  color: #F8F8F0;
  background-color: #F92672;
}

.ace-tungsten .ace_invalid.ace_deprecated {
  color: #F8F8F0;
  background-color: #AE81FF;
}

.ace-tungsten .ace_string {
  color: #E6DB74;
}

.ace-tungsten .ace_comment {
  color: #75715E;
}

.ace-tungsten .ace_variable {
  color: #A6E22E;
}

.ace-tungsten .ace_variable.ace_parameter {
  font-style: italic;
  color: #FD971F;
}

.ace-tungsten .ace_entity.ace_other.ace_attribute-name {
  color: #A6E22E;
}

.ace-tungsten .ace_entity.ace_name.ace_function {
  color: #A6E22E;
}

.ace-tungsten .ace_entity.ace_name.ace_tag {
  color: #F92672;
}

.ace-tungsten .ace_indent-guide {
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAAEklEQVQImWNgYGBgYHB3d/8PAAOIAdULw8qMAAAAAElFTkSuQmCC) right repeat-y
}

.ace-tungsten .ace_indent-guide-active {
  background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACAQMAAACjTyRkAAAABlBMVEUAAADCwsK76u2xAAAAAXRSTlMAQObYZgAAAAxJREFUCNdjYGBoAAAAhACBGFbxzQAAAABJRU5ErkJggg==") right repeat-y;
}`;

    var dom = require("../lib/dom");
    dom.importCssString(exports.cssText, exports.cssClass);
});